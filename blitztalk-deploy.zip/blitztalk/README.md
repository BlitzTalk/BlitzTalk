# 🏈 BLITZ TALK — Deployment Guide

## What's in this package
```
blitztalk/
├── api/
│   └── chat.js          ← Secure backend proxy (your API key lives here)
├── public/
│   └── index.html       ← Full frontend (all-in-one, no build needed)
├── vercel.json          ← Vercel config
└── README.md
```

---

## ✅ STEP 1 — Get Your Anthropic API Key
1. Go to **https://console.anthropic.com**
2. Sign up / log in
3. Click **"API Keys"** in the left sidebar
4. Click **"Create Key"** → name it "BlitzTalk" → copy it
5. Keep it safe — you'll need it in Step 3

---

## ✅ STEP 2 — Create a Free Vercel Account
1. Go to **https://vercel.com**
2. Click **"Sign Up"** → use GitHub, Google, or email
3. Free tier is all you need

---

## ✅ STEP 3 — Deploy to Vercel

### Option A: Drag & Drop (Easiest)
1. Zip the entire `blitztalk` folder
2. Go to **https://vercel.com/new**
3. Drag and drop your zip file
4. Click **Deploy**

### Option B: GitHub (Best for updates)
1. Create a free GitHub account at **github.com**
2. Create a new repository called `blitztalk`
3. Upload all files in this folder
4. In Vercel → "Add New Project" → Import from GitHub
5. Select your repo → Deploy

---

## ✅ STEP 4 — Add Your API Key (CRITICAL)
This is what makes Blitz answer questions live:

1. In Vercel, go to your project dashboard
2. Click **Settings** → **Environment Variables**
3. Click **Add New**
4. Name: `ANTHROPIC_API_KEY`
5. Value: paste your key from Step 1 (starts with `sk-ant-...`)
6. Click **Save**
7. Go to **Deployments** → click the 3 dots on latest deploy → **Redeploy**

---

## ✅ STEP 5 — You're Live! 🎉
Vercel gives you a URL like: `https://blitztalk.vercel.app`

That's your live Blitz Talk platform! Share it on all your socials.

---

## 💡 Tips
- **Custom domain**: In Vercel Settings → Domains → add your own domain (e.g. blitztalk.com)
- **Updates**: Just re-upload files or push to GitHub and Vercel auto-deploys
- **API costs**: Anthropic charges per message. Monitor usage at console.anthropic.com

---

## 🔒 Security Note
Your API key is NEVER exposed to users. It lives only in Vercel's secure environment variables and runs server-side in `api/chat.js`. This is the correct, safe way to deploy AI apps.
