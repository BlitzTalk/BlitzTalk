export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  const apiKey = process.env.ANTHROPIC_API_KEY || "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";

  try {
    const { messages, system } = req.body;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "web-search-2025-03-05"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: system,
        messages: messages,
        tools: [{ type: "web_search_20250305", name: "web_search" }]
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({ error: data.error?.message || "Anthropic API error" });
    }

    const text = data.content
      ?.filter(b => b.type === "text")
      .map(b => b.text)
      .join("") || "No response generated.";

    return res.status(200).json({ reply: text });

  } catch (err) {
    console.error("Proxy error:", err);
    return res.status(500).json({ error: "Server error. Try again." });
  }
}
